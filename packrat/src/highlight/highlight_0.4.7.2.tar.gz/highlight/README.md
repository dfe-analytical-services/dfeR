highlight
=========

[![Build Status](https://travis-ci.org/romainfrancois/highlight.png)](https://travis-ci.org/romainfrancois/highlight)

Syntax highlighter for R based on [highlight](http://www.andre-simon.de/doku/highlight/en/highlight.html)

