LATEX_SIZES <- c( "normalsize", "tiny","scriptsize", "footnotesize", "small",  
		"large", "Large", "LARGE", "huge", "Huge" )

